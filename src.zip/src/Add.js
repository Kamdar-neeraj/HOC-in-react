import React from "react";
class Add extends React.Component {
  constructor(props) {
    super(props);
    this.fun = this.fun.bind(this);
    this.a = React.createRef();
    this.b = React.createRef();
    this.state = { res: "" };
  }

  fun(e) {
    var a1 = +this.a.current.value;
    var b2 = +this.b.current.value;
    this.setState({ res: "additon is " + (a1 + b2) });
    e.preventDefault();
  }
  render() {
    return (
      <div>
        <h2>Addition Component Functionality </h2>
        <form onSubmit={this.fun}>
          <input type="text" placeholder="enter first no" ref={this.a} />
          <br />
          <input type="text" placeholder="enter second no" ref={this.b} />
          <br />
          <input type="submit" value="click" />
        </form>

        <p>{this.state.res}</p>
      </div>
    );
  }
}
export default Add;
