import React from "react";
class Sub extends React.Component {
  constructor(props) {
    super(props);
    this.fun = this.fun.bind(this);
    this.fun1 = this.fun1.bind(this);
    this.fun2 = this.fun2.bind(this);

    this.state = { res: "", num1: null, num2: null };
  }
  fun1(e) {
    this.setState({ num1: e.target.value });
  }
  fun2(e) {
    this.setState({ num2: e.target.value });
  }
  fun(e) {
    var a1 = +this.state.num1;
    var b2 = +this.state.num2;
    this.setState({ res: "substraction is " + (a1 - b2) });
    e.preventDefault();
  }
  render() {
    return (
      <div>
        <h2>Substraction Component Functionality </h2>
        <form onSubmit={this.fun}>
          <input
            type="text"
            placeholder="enter first no"
            onChange={this.fun1}
          />
          <br />
          <input
            type="text"
            placeholder="enter second no"
            onChange={this.fun2}
          />
          <br />
          <input type="submit" value="click" />
        </form>

        <p>{this.state.res}</p>
      </div>
    );
  }
}
export default Sub;
