import React from "react";
import Hoc from "./Hoc";
import Add from "./Add";
import Sub from "./Sub";
import Multi from "./Multi";
import Div from "./Div";

class App extends React.Component {
  render() {
    return (
      <div>
        <h2>APP Component Functionality</h2>
      </div>
    );
  }
}
App = Hoc(Add, Sub, Multi, Div);
// App = Hoc(Sub);
// App = Hoc(Multi);
// App = Hoc(Div);
export default App;
