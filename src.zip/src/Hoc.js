import React, { Component } from "react";

export default function Hoc(HocComponent, Hoc2, Hoc3, Hoc4) {
  return class extends Component {
    constructor() {
      super();
      this.state = { component: <HocComponent></HocComponent> };
    }
    render() {
      return (
        <div className="row" style={{ display: "flex" }}>
          <div className="col-3" style={{ width: "30%" }}>
            <p>This is High Order Component </p>
            <button
              onClick={() =>
                this.setState({ component: <HocComponent></HocComponent> })
              }
            >
              add
            </button>
            <button onClick={() => this.setState({ component: <Hoc2></Hoc2> })}>
              sub
            </button>
            <button onClick={() => this.setState({ component: <Hoc3 /> })}>
              sub2
            </button>
            <button onClick={() => this.setState({ component: <Hoc4 /> })}>
              sub2
            </button>
          </div>
          <div className="col-9" style={{ width: "70%" }}>
            {this.state.component}
          </div>
        </div>
      );
    }
  };
}
